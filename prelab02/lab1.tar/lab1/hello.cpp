// Hello, World
// This is the preferred notation for comments
/* This is the passé comment format */
#include <stdio.h>
#define PI 3.14159
int main(){
  double two_pi;
  printf("Hello World\n");
  two_pi = 2.0 * PI;
  printf("%lf %lf\n",PI,two_pi);
  return 0;  
}
